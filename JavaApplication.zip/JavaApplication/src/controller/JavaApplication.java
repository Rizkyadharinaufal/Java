/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.JDBCType;
import java.sql.SQLDataException;
/**
 *
 * @author Wildany Y Firdaus
 */
public class JavaApplication {

    /**
     * @param args the command line arguments
     */
     private static Connection koneksi;
    public  static Connection connect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Koneksi Berhasil");
        }
        catch (ClassNotFoundException ex){
            System.out.println("Koneksi Gagal"+ex);
        }
        String url= "jdbc:mysql://localhost/shoppingdb";
        try{
            koneksi = DriverManager.getConnection(url,"root","");
            System.out.println("Berhasil Koneksi Database");
        }
        catch(SQLException ex){
            System.out.println("Gagal Koneksi Database");
        }
        return koneksi;
    }
    
}
